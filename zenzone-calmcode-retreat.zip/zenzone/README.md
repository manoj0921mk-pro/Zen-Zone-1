# ZenZone: CalmCode Retreat

A calm-break web app for students: guided breathing (box, 4-7-8, 4-2-6), Exam Panic SOS, desk yoga,
ambient sounds, a meditation timer and a **private, per-user mood journal** with streaks, trend
analysis and personalised exercise suggestions.

**Stack:** HTML5 + CSS3 + vanilla JavaScript (ES modules) front end · TypeScript + Express back end ·
SQLite (better-sqlite3) · Zod validation · JWT auth · Vitest + Supertest tests.

## Run it

```bash
npm install
cp .env.example .env      # optional; sensible dev defaults exist
npm run dev               # http://localhost:3000   (API docs: /docs)
npm test                  # backend + frontend tests
npm run test:coverage
npm run build && npm start   # production (requires JWT_SECRET)
```

Requires Node 18+. In production set `NODE_ENV=production` and a private `JWT_SECRET`
(`openssl rand -hex 32`); the app refuses to start with the dev default.

## Architecture (3 layers + composition root)

```
backend/src
  app.ts            composition root: wires everything, no business logic
  server.ts         process start-up + graceful shutdown
  config/           env parsing/validation (Zod), AppConfig
  routes/           URL -> middleware -> controller
  controllers/      HTTP in/out only (cookies, status codes)
  services/         business rules (auth, mood journal, insights)
  repositories/     the only code that talks SQL
  db/               connection, versioned migrations, migration runner
  schemas/          Zod request schemas
  middleware/       auth, CSRF, validation, rate limits, error handler
  errors/           AppError + ValidationError, AuthError, ForbiddenError, NotFoundError, ConflictError
  docs/             OpenAPI spec served at /docs
frontend/
  index.html  css/style.css
  js/logic.js (pure, tested)  api.js (fetch + CSRF)  ui.js (DOM render)  features.js (timers/audio)  app.js (wiring)
  sw.js + manifest.webmanifest   installable, works offline for the calm tools
```

Dependencies point one way (routes -> controllers -> services -> repositories -> db). The database is
injected, so tests use an in-memory SQLite and the repository layer is the only place to change to
move to PostgreSQL.

## API (full docs at `/docs`)

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | /api/health | - | health check |
| GET | /api/csrf-token | - | issue CSRF token |
| POST | /api/auth/register | - | create account + log in |
| POST | /api/auth/login | - | log in |
| POST | /api/auth/logout | - | log out |
| GET | /api/auth/me | yes | current user |
| GET | /api/moods | yes | last 30 check-ins |
| POST | /api/moods | yes | save/update today's check-in |
| DELETE | /api/moods | yes | delete my check-ins |
| GET | /api/moods/insights | yes | average, trend, streak, recommendation |

Errors are always `{ "error": { "code", "message", "details?" } }`.

## Security

- Passwords hashed with bcrypt; login timing and messages do not reveal which emails exist
- JWT (HS256, pinned algorithm) in an `httpOnly`, `SameSite=Strict`, `Secure` (prod) cookie
- **CSRF protection:** double-submit token, compared in constant time, required on every POST/DELETE
- Helmet with a strict Content-Security-Policy (no inline scripts or styles anywhere in the front end)
- Zod validation on every input (`.strict()` rejects unknown fields); parameterised SQL only
- Rate limiting: 300 requests / 15 min overall, 10 / 15 min on login and register
- Body size limit (10 KB), generic 500 responses (no stack traces or SQL errors leaked)
- All user text is rendered with `textContent` (XSS-safe); data is private per user at the query level

## Innovation features

- Mood **insights engine**: streak, average, trend (improving/steady/rising) and a personalised
  recommendation (e.g. high stress -> Exam Panic SOS, anxious -> 4-7-8 breathing, tired -> desk yoga)
- **Adjustable breathing patterns** with a tested state machine
- **Offline-capable PWA** (service worker + manifest)

## Testing

`backend/tests` (auth, CSRF, rate limit, validation, per-user isolation, errors, migrations, insights)
and `frontend/tests` (logic, DOM rendering incl. XSS, API client incl. CSRF retry).

## Known limits / future work

SQLite is single-node (swap the repository layer for PostgreSQL to scale out); no password reset or
email verification; sessions are 2 hours with no refresh token.
