import { describe, expect, it } from 'vitest';
import { buildApp, creds, newSession } from './helpers';

describe('auth API', () => {
  it('registers a user, sets a secure session cookie and never returns the password hash', async () => {
    const { app } = buildApp();
    const s = await newSession(app);
    const res = await s.post('/api/auth/register', creds());

    expect(res.status).toBe(201);
    expect(res.body.user).toEqual({ id: expect.any(Number), email: 'student@example.com' });
    expect(JSON.stringify(res.body)).not.toMatch(/hash|password/i);

    const cookies = (res.headers['set-cookie'] as unknown as string[]).join(';');
    expect(cookies).toMatch(/token=/);
    expect(cookies).toMatch(/HttpOnly/i);
    expect(cookies).toMatch(/SameSite=Strict/i);
  });

  it('normalises the email (trim + lowercase)', async () => {
    const { app } = buildApp();
    const s = await newSession(app);
    const res = await s.post('/api/auth/register', { email: '  Student@Example.COM ', password: 'Calm1234' });
    expect(res.status).toBe(201);
    expect(res.body.user.email).toBe('student@example.com');
  });

  it('rejects a duplicate email with 409', async () => {
    const { app } = buildApp();
    const s = await newSession(app);
    await s.post('/api/auth/register', creds());
    const res = await s.post('/api/auth/register', creds());
    expect(res.status).toBe(409);
    expect(res.body.error.code).toBe('CONFLICT');
  });

  it.each([
    ['too short', { email: 'a@b.co', password: 'a1' }],
    ['no number', { email: 'a@b.co', password: 'onlyletters' }],
    ['no letter', { email: 'a@b.co', password: '12345678' }],
    ['bad email', { email: 'not-an-email', password: 'Calm1234' }],
    ['extra field', { email: 'a@b.co', password: 'Calm1234', isAdmin: true }],
    ['missing body', {}],
  ])('rejects invalid registration (%s) with 400 and field details', async (_name, body) => {
    const { app } = buildApp();
    const s = await newSession(app);
    const res = await s.post('/api/auth/register', body);
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
    expect(Array.isArray(res.body.error.details)).toBe(true);
  });

  it('logs in with correct credentials and rejects wrong ones with a generic message', async () => {
    const { app } = buildApp();
    const s = await newSession(app);
    await s.post('/api/auth/register', creds());

    const fresh = await newSession(app);
    const ok = await fresh.post('/api/auth/login', creds());
    expect(ok.status).toBe(200);

    const wrongPassword = await fresh.post('/api/auth/login', creds('student@example.com', 'Wrong1234'));
    const unknownUser = await fresh.post('/api/auth/login', creds('nobody@example.com'));
    expect(wrongPassword.status).toBe(401);
    expect(unknownUser.status).toBe(401);
    // Same message either way, so attackers cannot discover which emails are registered.
    expect(wrongPassword.body.error.message).toBe(unknownUser.body.error.message);
  });

  it('GET /me requires login, then returns the current user', async () => {
    const { app } = buildApp();
    const s = await newSession(app);
    expect((await s.get('/api/auth/me')).status).toBe(401);

    await s.post('/api/auth/register', creds());
    const me = await s.get('/api/auth/me');
    expect(me.status).toBe(200);
    expect(me.body.user.email).toBe('student@example.com');
  });

  it('logout clears the session', async () => {
    const { app } = buildApp();
    const s = await newSession(app);
    await s.post('/api/auth/register', creds());
    expect((await s.post('/api/auth/logout')).status).toBe(204);
    expect((await s.get('/api/auth/me')).status).toBe(401);
  });

  it('rejects a tampered token', async () => {
    const { app } = buildApp();
    const s = await newSession(app);
    const res = await s.agent.get('/api/auth/me').set('Cookie', 'token=not.a.real.jwt');
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe('AUTH_ERROR');
  });
});
