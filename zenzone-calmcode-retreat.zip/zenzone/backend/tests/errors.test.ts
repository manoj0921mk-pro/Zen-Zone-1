import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { AppError, ConflictError, ForbiddenError, NotFoundError, ValidationError, AuthError } from '../src/errors/AppError';
import { runMigrations } from '../src/db/migrate';
import { createDatabase } from '../src/db/database';
import { buildApp, loggedInSession, newSession } from './helpers';

describe('error handling', () => {
  it('returns JSON 404 for unknown API routes and unknown pages', async () => {
    const { app } = buildApp();
    const api = await request(app).get('/api/nope');
    expect(api.status).toBe(404);
    expect(api.body.error.code).toBe('NOT_FOUND');
    expect((await request(app).get('/definitely-missing.html')).status).toBe(404);
  });

  it('returns 400 INVALID_JSON for malformed JSON', async () => {
    const { app } = buildApp();
    const s = await newSession(app);
    const res = await s.agent
      .post('/api/auth/login')
      .set('X-CSRF-Token', s.token)
      .set('Content-Type', 'application/json')
      .send('{"email": ');
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('INVALID_JSON');
  });

  it('hides internal details on unexpected failures (500)', async () => {
    const { app, db } = buildApp();
    const s = await loggedInSession(app);
    db.close(); // force the database layer to blow up
    const res = await s.get('/api/moods');
    expect(res.status).toBe(500);
    expect(res.body.error.code).toBe('INTERNAL_ERROR');
    expect(JSON.stringify(res.body)).not.toMatch(/sqlite|database|stack|at .*\(/i);
  });

  it('domain error classes carry the right status and code', () => {
    expect(new ValidationError()).toMatchObject({ statusCode: 400, code: 'VALIDATION_ERROR' });
    expect(new AuthError()).toMatchObject({ statusCode: 401, code: 'AUTH_ERROR' });
    expect(new ForbiddenError()).toMatchObject({ statusCode: 403, code: 'FORBIDDEN' });
    expect(new NotFoundError()).toMatchObject({ statusCode: 404, code: 'NOT_FOUND' });
    expect(new ConflictError()).toMatchObject({ statusCode: 409, code: 'CONFLICT' });
    expect(new ConflictError()).toBeInstanceOf(AppError);
    expect(new ConflictError().name).toBe('ConflictError');
  });
});

describe('database migrations', () => {
  it('are idempotent: running twice applies nothing the second time', () => {
    const db = createDatabase(':memory:');
    expect(runMigrations(db)).toBe(0);
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all() as { name: string }[];
    expect(tables.map((t) => t.name)).toEqual(expect.arrayContaining(['users', 'mood_entries', 'schema_migrations']));
  });

  it('creates the lookup index on mood_entries', () => {
    const db = createDatabase(':memory:');
    const idx = db.prepare("SELECT name FROM sqlite_master WHERE type='index'").all() as { name: string }[];
    expect(idx.map((i) => i.name)).toContain('idx_mood_entries_user_date');
  });
});

describe('static front end', () => {
  it('serves the HTML app at /', async () => {
    const { app } = buildApp();
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    expect(res.text).toContain('ZenZone');
  });
});
