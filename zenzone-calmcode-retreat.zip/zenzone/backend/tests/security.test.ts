import request from 'supertest';
import { describe, expect, it } from 'vitest';
import { buildApp, creds, newSession } from './helpers';

describe('security', () => {
  it('blocks state-changing requests without a CSRF token (403)', async () => {
    const { app } = buildApp();
    const res = await request(app).post('/api/auth/register').send(creds());
    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('FORBIDDEN');
  });

  it('blocks requests whose CSRF header does not match the cookie', async () => {
    const { app } = buildApp();
    const agent = request.agent(app);
    await agent.get('/api/csrf-token');
    const res = await agent.post('/api/auth/register').set('X-CSRF-Token', 'f'.repeat(64)).send(creds());
    expect(res.status).toBe(403);
  });

  it('keeps the same CSRF token across calls so several tabs keep working', async () => {
    const { app } = buildApp();
    const agent = request.agent(app);
    const a = await agent.get('/api/csrf-token');
    const b = await agent.get('/api/csrf-token');
    expect(a.body.csrfToken).toBe(b.body.csrfToken);
  });

  it('sends Helmet security headers and a strict CSP, and hides x-powered-by', async () => {
    const { app } = buildApp();
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['content-security-policy']).toContain("default-src 'self'");
    expect(res.headers['content-security-policy']).toContain("script-src 'self'");
  });

  it('rate-limits repeated login attempts (429)', async () => {
    const { app } = buildApp({ rateLimitEnabled: true });
    const s = await newSession(app);
    let last = 0;
    for (let i = 0; i < 12; i++) {
      last = (await s.post('/api/auth/login', creds('x@y.com', 'Wrong1234'))).status;
    }
    expect(last).toBe(429);
  });

  it('rejects oversized request bodies (413)', async () => {
    const { app } = buildApp();
    const s = await newSession(app);
    const res = await s.post('/api/auth/login', { email: 'a@b.co', password: 'x'.repeat(20_000) });
    expect(res.status).toBe(413);
  });
});
