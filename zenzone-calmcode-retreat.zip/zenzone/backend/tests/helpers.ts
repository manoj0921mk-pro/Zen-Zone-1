import path from 'path';
import request from 'supertest';
import { createApp } from '../src/app';
import type { AppConfig } from '../src/config/env';
import { createDatabase } from '../src/db/database';

export const testConfig: AppConfig = {
  jwtSecret: 'test-secret-test-secret-123',
  jwtExpiresSeconds: 3600,
  bcryptRounds: 4, // fast hashing for tests only
  rateLimitEnabled: false,
  secureCookies: false,
  frontendDir: path.resolve(__dirname, '../../frontend'),
  logLevel: 'silent',
  logEnabled: false,
};

export function buildApp(overrides: Partial<AppConfig> = {}) {
  const db = createDatabase(':memory:');
  const app = createApp({ db, config: { ...testConfig, ...overrides } });
  return { app, db };
}

/** A browser-like session: keeps cookies and automatically sends the CSRF header. */
export async function newSession(app: ReturnType<typeof createApp>) {
  const agent = request.agent(app);
  const res = await agent.get('/api/csrf-token');
  const token = res.body.csrfToken as string;
  return {
    agent,
    token,
    get: (url: string) => agent.get(url),
    post: (url: string, body?: object) => agent.post(url).set('X-CSRF-Token', token).send(body),
    del: (url: string) => agent.delete(url).set('X-CSRF-Token', token),
  };
}

export const creds = (email = 'student@example.com', password = 'Calm1234') => ({ email, password });

export async function loggedInSession(app: ReturnType<typeof createApp>, email = 'student@example.com') {
  const s = await newSession(app);
  const res = await s.post('/api/auth/register', creds(email));
  if (res.status !== 201) throw new Error(`register failed: ${res.status}`);
  return s;
}
