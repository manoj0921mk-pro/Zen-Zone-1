import { describe, expect, it } from 'vitest';
import { computeInsights, recommend } from '../src/services/insights.service';
import type { Mood, MoodEntry } from '../src/types/domain';
import { shiftDay } from '../src/utils/dates';

let id = 0;
const e = (entryDate: string, stress: number, mood: Mood = 'neutral'): MoodEntry => ({
  id: ++id, entryDate, stress, mood, note: '', createdAt: '',
});

describe('computeInsights', () => {
  it('handles no data', () => {
    const r = computeInsights([], '2026-11-26');
    expect(r).toMatchObject({ entryCount: 0, averageStress: null, streak: 0, trend: 'not-enough-data' });
    expect(r.recommendation.action).toBe('breathing:box');
  });

  it('counts a streak ending today', () => {
    const r = computeInsights([e('2026-11-24', 3), e('2026-11-25', 3), e('2026-11-26', 3)], '2026-11-26');
    expect(r.streak).toBe(3);
  });

  it('keeps the streak alive if today is not saved yet but yesterday was', () => {
    expect(computeInsights([e('2026-11-24', 3), e('2026-11-25', 3)], '2026-11-26').streak).toBe(2);
  });

  it('breaks the streak after a missed day', () => {
    expect(computeInsights([e('2026-11-22', 3), e('2026-11-26', 3)], '2026-11-26').streak).toBe(1);
    expect(computeInsights([e('2026-11-20', 3)], '2026-11-26').streak).toBe(0);
  });

  it('detects an improving trend', () => {
    const entries = [5, 5, 4, 2, 2, 1].map((s, i) => e(shiftDay('2026-11-20', i), s));
    expect(computeInsights(entries, '2026-11-25').trend).toBe('improving');
  });

  it('detects a worsening trend', () => {
    const entries = [1, 2, 2, 4, 5, 5].map((s, i) => e(shiftDay('2026-11-20', i), s));
    expect(computeInsights(entries, '2026-11-25').trend).toBe('worsening');
  });

  it('needs at least 4 entries to call a trend', () => {
    expect(computeInsights([e('2026-11-24', 1), e('2026-11-25', 5)], '2026-11-25').trend).toBe('not-enough-data');
  });

  it('rounds the average to one decimal', () => {
    expect(computeInsights([e('2026-11-24', 1), e('2026-11-25', 2), e('2026-11-26', 2)], '2026-11-26').averageStress).toBe(1.7);
  });
});

describe('recommend', () => {
  it.each([
    [{ stress: 5, mood: 'neutral' }, 'sos'],
    [{ stress: 3, mood: 'anxious' }, 'breathing:relax'],
    [{ stress: 3, mood: 'tired' }, 'yoga'],
    [{ stress: 1, mood: 'happy' }, 'meditation'],
    [{ stress: 3, mood: 'neutral' }, 'breathing:box'],
  ] as const)('%j -> %s', (input, action) => {
    expect(recommend(e('2026-11-26', input.stress, input.mood as Mood)).action).toBe(action);
  });
});
