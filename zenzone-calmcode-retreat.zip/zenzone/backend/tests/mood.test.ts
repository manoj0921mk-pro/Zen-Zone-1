import { describe, expect, it } from 'vitest';
import { buildApp, loggedInSession, newSession } from './helpers';

const entry = (over: object = {}) => ({ entryDate: '2026-11-20', mood: 'calm', stress: 2, note: 'Fine', ...over });

describe('mood journal API', () => {
  it('requires authentication', async () => {
    const { app } = buildApp();
    const s = await newSession(app);
    expect((await s.get('/api/moods')).status).toBe(401);
    expect((await s.post('/api/moods', entry())).status).toBe(401);
    expect((await s.get('/api/moods/insights')).status).toBe(401);
  });

  it('saves and lists entries oldest-first', async () => {
    const { app } = buildApp();
    const s = await loggedInSession(app);
    await s.post('/api/moods', entry({ entryDate: '2026-11-21', stress: 4 }));
    await s.post('/api/moods', entry({ entryDate: '2026-11-20', stress: 1 }));

    const res = await s.get('/api/moods');
    expect(res.status).toBe(200);
    expect(res.body.entries.map((e: { entryDate: string }) => e.entryDate)).toEqual(['2026-11-20', '2026-11-21']);
  });

  it('updates the existing entry when saving the same date again', async () => {
    const { app } = buildApp();
    const s = await loggedInSession(app);
    await s.post('/api/moods', entry({ stress: 5, mood: 'anxious' }));
    await s.post('/api/moods', entry({ stress: 1, mood: 'happy', note: 'Better now' }));

    const { entries } = (await s.get('/api/moods')).body;
    expect(entries).toHaveLength(1);
    expect(entries[0]).toMatchObject({ stress: 1, mood: 'happy', note: 'Better now' });
  });

  it.each([
    ['stress too high', { stress: 9 }],
    ['stress too low', { stress: 0 }],
    ['stress not an integer', { stress: 2.5 }],
    ['stress as a string', { stress: '3' }],
    ['unknown mood', { mood: 'angry' }],
    ['note too long', { note: 'x'.repeat(501) }],
    ['bad date format', { entryDate: '26/11/2026' }],
    ['impossible date', { entryDate: '2026-02-31' }],
    ['future date', { entryDate: '2999-01-01' }],
    ['unknown field', { role: 'admin' }],
  ])('rejects invalid input: %s', async (_name, over) => {
    const { app } = buildApp();
    const s = await loggedInSession(app);
    const res = await s.post('/api/moods', entry(over));
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
  });

  it('stores notes as plain text (no HTML interpretation on the server)', async () => {
    const { app } = buildApp();
    const s = await loggedInSession(app);
    const note = '<script>alert(1)</script>';
    await s.post('/api/moods', entry({ note }));
    expect((await s.get('/api/moods')).body.entries[0].note).toBe(note);
  });

  it("keeps each user's data private", async () => {
    const { app } = buildApp();
    const alice = await loggedInSession(app, 'alice@example.com');
    const bob = await loggedInSession(app, 'bob@example.com');
    await alice.post('/api/moods', entry({ note: 'alice secret' }));

    expect((await bob.get('/api/moods')).body.entries).toEqual([]);
    await bob.del('/api/moods'); // must not touch Alice's data
    expect((await alice.get('/api/moods')).body.entries).toHaveLength(1);
  });

  it('clears all of my entries', async () => {
    const { app } = buildApp();
    const s = await loggedInSession(app);
    await s.post('/api/moods', entry());
    expect((await s.del('/api/moods')).status).toBe(204);
    expect((await s.get('/api/moods')).body.entries).toEqual([]);
  });

  it('returns insights using the date supplied by the browser', async () => {
    const { app } = buildApp();
    const s = await loggedInSession(app);
    await s.post('/api/moods', entry({ entryDate: '2026-11-25', stress: 2 }));
    await s.post('/api/moods', entry({ entryDate: '2026-11-26', stress: 5 }));

    const res = await s.get('/api/moods/insights?today=2026-11-26');
    expect(res.status).toBe(200);
    expect(res.body.insights).toMatchObject({ entryCount: 2, streak: 2, averageStress: 3.5 });
    expect(res.body.insights.recommendation.action).toBe('sos');

    expect((await s.get('/api/moods/insights?today=nonsense')).status).toBe(400);
  });
});
