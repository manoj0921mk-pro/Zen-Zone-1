import { z } from 'zod';
import { MOODS } from '../types/domain';

export const isoDate = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be in YYYY-MM-DD format')
  .refine((s) => new Date(`${s}T00:00:00Z`).toISOString().slice(0, 10) === s, 'Date is not a real calendar date');

export const moodInputSchema = z
  .object({
    entryDate: isoDate.optional(),
    mood: z.enum(MOODS, { errorMap: () => ({ message: `Mood must be one of: ${MOODS.join(', ')}` }) }),
    stress: z
      .number({ required_error: 'Stress is required', invalid_type_error: 'Stress must be a number' })
      .int('Stress must be a whole number')
      .min(1, 'Stress must be between 1 and 5')
      .max(5, 'Stress must be between 1 and 5'),
    note: z.string().trim().max(500, 'Note must be 500 characters or fewer').default(''),
  })
  .strict();

export const insightsQuerySchema = z.object({ today: isoDate.optional() });

export type MoodInput = z.infer<typeof moodInputSchema>;
