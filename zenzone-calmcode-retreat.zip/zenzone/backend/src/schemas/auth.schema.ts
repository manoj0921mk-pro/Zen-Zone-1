import { z } from 'zod';

const email = z
  .string({ required_error: 'Email is required' })
  .trim()
  .toLowerCase()
  .email('Enter a valid email address')
  .max(254, 'Email is too long');

export const registerSchema = z
  .object({
    email,
    password: z
      .string({ required_error: 'Password is required' })
      .min(8, 'Password must be at least 8 characters')
      .max(72, 'Password must be 72 characters or fewer')
      .regex(/[A-Za-z]/, 'Password must contain a letter')
      .regex(/\d/, 'Password must contain a number'),
  })
  .strict();

export const loginSchema = z
  .object({
    email,
    password: z.string({ required_error: 'Password is required' }).min(1, 'Password is required').max(72),
  })
  .strict();
