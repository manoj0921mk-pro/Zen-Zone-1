export interface Migration {
  id: number;
  name: string;
  sql: string;
}

/** Append-only list. Never edit a migration that has shipped: add a new one instead. */
export const migrations: Migration[] = [
  {
    id: 1,
    name: 'create_users',
    sql: `
      CREATE TABLE users (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        email         TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        created_at    TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `,
  },
  {
    id: 2,
    name: 'create_mood_entries',
    sql: `
      CREATE TABLE mood_entries (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        entry_date TEXT NOT NULL,
        mood       TEXT NOT NULL CHECK (mood IN ('happy','calm','neutral','anxious','tired')),
        stress     INTEGER NOT NULL CHECK (stress BETWEEN 1 AND 5),
        note       TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE (user_id, entry_date)
      );
      CREATE INDEX idx_mood_entries_user_date ON mood_entries (user_id, entry_date DESC);
    `,
  },
];
