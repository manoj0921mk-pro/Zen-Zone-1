import Database from 'better-sqlite3';
import { runMigrations } from './migrate';

export type DB = Database.Database;

/** Opens the database (use ':memory:' in tests), enables safety pragmas and runs migrations. */
export function createDatabase(file: string): DB {
  const db = new Database(file);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  runMigrations(db);
  return db;
}
