/** Today's date as YYYY-MM-DD in UTC (server fallback; the browser sends its own local date). */
export function todayUtc(now: Date = new Date()): string {
  return now.toISOString().slice(0, 10);
}

/** Adds (or subtracts) whole days to a YYYY-MM-DD string without timezone surprises. */
export function shiftDay(iso: string, delta: number): string {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + delta)).toISOString().slice(0, 10);
}
