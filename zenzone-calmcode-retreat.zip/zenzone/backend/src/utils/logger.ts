import pino, { Logger } from 'pino';

export function createLogger(opts: { level: string; enabled: boolean }): Logger {
  return pino({
    level: opts.level,
    enabled: opts.enabled,
    redact: ['req.headers.cookie', 'password', '*.password'],
  });
}
