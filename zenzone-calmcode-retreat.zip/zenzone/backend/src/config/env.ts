import path from 'path';
import { z } from 'zod';

const DEFAULT_SECRET = 'dev-only-secret-change-me-please';

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().min(1).max(65535).default(3000),
  DB_PATH: z.string().min(1).default('zenzone.db'),
  JWT_SECRET: z.string().min(16, 'JWT_SECRET must be at least 16 characters').default(DEFAULT_SECRET),
  JWT_EXPIRES_SECONDS: z.coerce.number().int().min(60).default(7200),
  BCRYPT_ROUNDS: z.coerce.number().int().min(4).max(14).default(10),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
});

export type Env = z.infer<typeof envSchema>;

/** Runtime settings the app needs. Passed into createApp so tests can override them. */
export interface AppConfig {
  jwtSecret: string;
  jwtExpiresSeconds: number;
  bcryptRounds: number;
  rateLimitEnabled: boolean;
  secureCookies: boolean;
  frontendDir: string;
  logLevel: string;
  logEnabled: boolean;
}

export function loadEnv(source: NodeJS.ProcessEnv = process.env): Env {
  const env = envSchema.parse(source);
  if (env.NODE_ENV === 'production' && env.JWT_SECRET === DEFAULT_SECRET) {
    throw new Error('JWT_SECRET must be set to a private value in production');
  }
  return env;
}

export function toAppConfig(env: Env): AppConfig {
  return {
    jwtSecret: env.JWT_SECRET,
    jwtExpiresSeconds: env.JWT_EXPIRES_SECONDS,
    bcryptRounds: env.BCRYPT_ROUNDS,
    rateLimitEnabled: env.NODE_ENV !== 'test',
    secureCookies: env.NODE_ENV === 'production',
    frontendDir: path.resolve(process.cwd(), 'frontend'),
    logLevel: env.LOG_LEVEL,
    logEnabled: env.NODE_ENV !== 'test',
  };
}
