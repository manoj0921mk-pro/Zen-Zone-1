import { RequestHandler, Router } from 'express';
import type { createMoodController } from '../controllers/mood.controller';
import { validate } from '../middleware/validate';
import { insightsQuerySchema, moodInputSchema } from '../schemas/mood.schema';

export function createMoodRouter(c: ReturnType<typeof createMoodController>, requireAuth: RequestHandler): Router {
  const router = Router();
  router.use(requireAuth); // every mood route is private to the logged-in user
  router.get('/', c.list);
  router.post('/', validate(moodInputSchema), c.save);
  router.delete('/', c.clear);
  router.get('/insights', validate(insightsQuerySchema, 'query'), c.insights);
  return router;
}
