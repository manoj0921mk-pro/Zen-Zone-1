import { RequestHandler, Router } from 'express';
import type { createAuthController } from '../controllers/auth.controller';
import { validate } from '../middleware/validate';
import { loginSchema, registerSchema } from '../schemas/auth.schema';

export function createAuthRouter(
  c: ReturnType<typeof createAuthController>,
  requireAuth: RequestHandler,
  authLimiter: RequestHandler,
): Router {
  const router = Router();
  router.post('/register', authLimiter, validate(registerSchema), c.register);
  router.post('/login', authLimiter, validate(loginSchema), c.login);
  router.post('/logout', c.logout);
  router.get('/me', requireAuth, c.me);
  return router;
}
