import { RequestHandler, Router } from 'express';
import type { createAuthController } from '../controllers/auth.controller';
import type { createMoodController } from '../controllers/mood.controller';
import { issueCsrfToken } from '../middleware/csrf';
import { NotFoundError } from '../errors/AppError';
import { createAuthRouter } from './auth.routes';
import { createMoodRouter } from './mood.routes';

export interface ApiDeps {
  authController: ReturnType<typeof createAuthController>;
  moodController: ReturnType<typeof createMoodController>;
  requireAuth: RequestHandler;
  authLimiter: RequestHandler;
  secureCookies: boolean;
}

export function createApiRouter(d: ApiDeps): Router {
  const router = Router();
  router.get('/health', (_req, res) => {
    res.json({ status: 'ok' });
  });
  router.get('/csrf-token', issueCsrfToken({ secure: d.secureCookies }));
  router.use('/auth', createAuthRouter(d.authController, d.requireAuth, d.authLimiter));
  router.use('/moods', createMoodRouter(d.moodController, d.requireAuth));
  router.use((_req, _res, next) => next(new NotFoundError('API endpoint not found.')));
  return router;
}
