import type { CookieOptions, RequestHandler } from 'express';
import { TOKEN_COOKIE } from '../middleware/auth';
import type { AuthService } from '../services/auth.service';
import { asyncHandler } from '../utils/asyncHandler';

export function createAuthController(auth: AuthService, opts: { secure: boolean; maxAgeMs: number }) {
  const cookie: CookieOptions = {
    httpOnly: true, // JavaScript can never read the session token
    sameSite: 'strict',
    secure: opts.secure,
    path: '/',
  };

  const register: RequestHandler = asyncHandler(async (req, res) => {
    const { user, token } = await auth.register(req.body.email, req.body.password);
    res.cookie(TOKEN_COOKIE, token, { ...cookie, maxAge: opts.maxAgeMs });
    res.status(201).json({ user });
  });

  const login: RequestHandler = asyncHandler(async (req, res) => {
    const { user, token } = await auth.login(req.body.email, req.body.password);
    res.cookie(TOKEN_COOKIE, token, { ...cookie, maxAge: opts.maxAgeMs });
    res.json({ user });
  });

  const logout: RequestHandler = (_req, res) => {
    res.clearCookie(TOKEN_COOKIE, cookie);
    res.status(204).end();
  };

  const me: RequestHandler = (req, res) => {
    res.json({ user: auth.getUser(req.userId as number) });
  };

  return { register, login, logout, me };
}
