import type { RequestHandler } from 'express';
import type { MoodService } from '../services/mood.service';

export function createMoodController(moods: MoodService) {
  const list: RequestHandler = (req, res) => {
    res.json({ entries: moods.list(req.userId as number) });
  };

  const save: RequestHandler = (req, res) => {
    res.json({ entry: moods.save(req.userId as number, req.body) });
  };

  const clear: RequestHandler = (req, res) => {
    moods.clear(req.userId as number);
    res.status(204).end();
  };

  const insights: RequestHandler = (req, res) => {
    const today = typeof req.query.today === 'string' ? req.query.today : undefined;
    res.json({ insights: moods.insights(req.userId as number, today) });
  };

  return { list, save, clear, insights };
}
