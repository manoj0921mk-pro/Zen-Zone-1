declare global {
  namespace Express {
    interface Request {
      /** Set by the requireAuth middleware once the JWT cookie has been verified. */
      userId?: number;
    }
  }
}
export {};
