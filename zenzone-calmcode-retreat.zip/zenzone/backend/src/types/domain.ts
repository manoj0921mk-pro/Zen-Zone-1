export const MOODS = ['happy', 'calm', 'neutral', 'anxious', 'tired'] as const;
export type Mood = (typeof MOODS)[number];

export interface MoodEntry {
  id: number;
  entryDate: string; // YYYY-MM-DD
  mood: Mood;
  stress: number; // 1..5
  note: string;
  createdAt: string;
}

export interface PublicUser {
  id: number;
  email: string;
}

export type RecommendationAction =
  | 'sos'
  | 'breathing:box'
  | 'breathing:relax'
  | 'breathing:calm'
  | 'yoga'
  | 'meditation';

export interface Recommendation {
  title: string;
  reason: string;
  action: RecommendationAction;
}

export type Trend = 'improving' | 'steady' | 'worsening' | 'not-enough-data';

export interface Insights {
  entryCount: number;
  averageStress: number | null;
  trend: Trend;
  streak: number;
  recommendation: Recommendation;
}
