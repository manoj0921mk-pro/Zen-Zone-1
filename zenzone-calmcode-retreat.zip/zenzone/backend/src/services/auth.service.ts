import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { AuthError, ConflictError } from '../errors/AppError';
import type { UserRepository } from '../repositories/user.repository';
import type { PublicUser } from '../types/domain';

export interface AuthOptions {
  secret: string;
  expiresSeconds: number;
  bcryptRounds: number;
}

export class AuthService {
  private readonly dummyHash: string;

  constructor(
    private readonly users: UserRepository,
    private readonly opts: AuthOptions,
  ) {
    // Compared against when the email is unknown so login timing does not reveal which emails exist.
    this.dummyHash = bcrypt.hashSync('not-a-real-password', opts.bcryptRounds);
  }

  async register(email: string, password: string): Promise<{ user: PublicUser; token: string }> {
    if (this.users.findByEmail(email)) {
      throw new ConflictError('An account with this email already exists.');
    }
    const hash = await bcrypt.hash(password, this.opts.bcryptRounds);
    const row = this.users.create(email, hash);
    return { user: { id: row.id, email: row.email }, token: this.sign(row.id) };
  }

  async login(email: string, password: string): Promise<{ user: PublicUser; token: string }> {
    const row = this.users.findByEmail(email);
    const ok = await bcrypt.compare(password, row?.password_hash ?? this.dummyHash);
    if (!row || !ok) throw new AuthError('Incorrect email or password.');
    return { user: { id: row.id, email: row.email }, token: this.sign(row.id) };
  }

  getUser(id: number): PublicUser {
    const row = this.users.findById(id);
    if (!row) throw new AuthError('Your account could not be found. Please log in again.');
    return { id: row.id, email: row.email };
  }

  verifyToken(token: string): number {
    try {
      const payload = jwt.verify(token, this.opts.secret, { algorithms: ['HS256'] });
      const id = Number(typeof payload === 'object' ? payload.sub : NaN);
      if (!Number.isInteger(id)) throw new Error('bad subject');
      return id;
    } catch {
      throw new AuthError('Your session has expired. Please log in again.');
    }
  }

  private sign(userId: number): string {
    return jwt.sign({}, this.opts.secret, {
      subject: String(userId),
      expiresIn: this.opts.expiresSeconds,
      algorithm: 'HS256',
    });
  }
}
