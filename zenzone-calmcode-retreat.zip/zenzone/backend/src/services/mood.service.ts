import { ValidationError } from '../errors/AppError';
import type { MoodInput } from '../schemas/mood.schema';
import type { MoodRepository } from '../repositories/mood.repository';
import type { Insights, MoodEntry } from '../types/domain';
import { shiftDay, todayUtc } from '../utils/dates';
import { computeInsights } from './insights.service';

const HISTORY_LIMIT = 30;

export class MoodService {
  constructor(private readonly repo: MoodRepository) {}

  save(userId: number, input: MoodInput): MoodEntry {
    const entryDate = input.entryDate ?? todayUtc();
    // Allow one day ahead so users east of UTC can save "today" before UTC rolls over.
    if (entryDate > shiftDay(todayUtc(), 1)) {
      throw new ValidationError('Entries cannot be dated in the future.', [
        { field: 'entryDate', message: 'Entries cannot be dated in the future.' },
      ]);
    }
    return this.repo.upsert(userId, {
      entryDate,
      mood: input.mood,
      stress: input.stress,
      note: input.note,
    });
  }

  list(userId: number): MoodEntry[] {
    return this.repo.recent(userId, HISTORY_LIMIT);
  }

  clear(userId: number): number {
    return this.repo.deleteAll(userId);
  }

  insights(userId: number, today: string = todayUtc()): Insights {
    return computeInsights(this.list(userId), today);
  }
}
