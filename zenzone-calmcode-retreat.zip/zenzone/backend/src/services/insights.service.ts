import type { Insights, MoodEntry, Recommendation, Trend } from '../types/domain';
import { shiftDay } from '../utils/dates';

const round1 = (n: number) => Math.round(n * 10) / 10;
const mean = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;

export function recommend(latest?: MoodEntry): Recommendation {
  if (!latest) {
    return {
      title: 'Box Breathing',
      reason: 'A great first reset: a steady 4-4-4-4 rhythm. Save a check-in to get personalised suggestions.',
      action: 'breathing:box',
    };
  }
  if (latest.stress >= 4) {
    return {
      title: 'Exam Panic SOS',
      reason: `Your last check-in showed high stress (${latest.stress}/5). A short guided reset can help.`,
      action: 'sos',
    };
  }
  if (latest.mood === 'anxious') {
    return {
      title: '4-7-8 Relaxing Breath',
      reason: 'You felt anxious last time. A longer exhale tells your body it is safe to slow down.',
      action: 'breathing:relax',
    };
  }
  if (latest.mood === 'tired') {
    return {
      title: 'Desk Yoga',
      reason: 'You felt tired last time. A few gentle stretches can bring energy back.',
      action: 'yoga',
    };
  }
  if (latest.stress <= 2) {
    return {
      title: '5-Minute Meditation',
      reason: 'You are feeling calm. Build on it with a short meditation.',
      action: 'meditation',
    };
  }
  return {
    title: 'Box Breathing',
    reason: 'A steady 4-4-4-4 rhythm keeps a moderate day from tipping into stress.',
    action: 'breathing:box',
  };
}

/** Pure function: entries in, insights out. `today` is YYYY-MM-DD in the user's timezone. */
export function computeInsights(entries: MoodEntry[], today: string): Insights {
  if (entries.length === 0) {
    return {
      entryCount: 0,
      averageStress: null,
      trend: 'not-enough-data',
      streak: 0,
      recommendation: recommend(),
    };
  }

  const sorted = [...entries].sort((a, b) => a.entryDate.localeCompare(b.entryDate));
  const stresses = sorted.map((e) => e.stress);

  let trend: Trend = 'not-enough-data';
  if (sorted.length >= 4) {
    const recent = stresses.slice(-3);
    const previous = stresses.slice(-6, -3);
    const diff = mean(recent) - mean(previous);
    trend = diff <= -0.5 ? 'improving' : diff >= 0.5 ? 'worsening' : 'steady';
  }

  // Streak: consecutive days with a check-in, ending today (or yesterday if today is not saved yet).
  const days = new Set(sorted.map((e) => e.entryDate));
  let cursor = days.has(today) ? today : shiftDay(today, -1);
  let streak = 0;
  while (days.has(cursor)) {
    streak++;
    cursor = shiftDay(cursor, -1);
  }

  return {
    entryCount: sorted.length,
    averageStress: round1(mean(stresses)),
    trend,
    streak,
    recommendation: recommend(sorted[sorted.length - 1]),
  };
}
