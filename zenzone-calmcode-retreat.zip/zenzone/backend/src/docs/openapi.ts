const errorResponse = {
  description: 'Error',
  content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } },
};
const csrf = [{ csrfToken: [] }];

export const openApiSpec = {
  openapi: '3.0.3',
  info: {
    title: 'ZenZone API',
    version: '2.0.0',
    description:
      'Auth uses an httpOnly JWT cookie. Every POST/DELETE also needs the X-CSRF-Token header (value from GET /api/csrf-token).',
  },
  servers: [{ url: '/' }],
  tags: [{ name: 'System' }, { name: 'Auth' }, { name: 'Mood journal' }],
  paths: {
    '/api/health': { get: { tags: ['System'], summary: 'Health check', responses: { 200: { description: 'OK' } } } },
    '/api/csrf-token': {
      get: { tags: ['System'], summary: 'Get a CSRF token (also sets the csrf_token cookie)', responses: { 200: { description: 'Token' } } },
    },
    '/api/auth/register': {
      post: {
        tags: ['Auth'], summary: 'Create an account and log in', security: csrf,
        requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Credentials' } } } },
        responses: { 201: { description: 'Created' }, 400: errorResponse, 403: errorResponse, 409: errorResponse, 429: errorResponse },
      },
    },
    '/api/auth/login': {
      post: {
        tags: ['Auth'], summary: 'Log in', security: csrf,
        requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Credentials' } } } },
        responses: { 200: { description: 'Logged in' }, 401: errorResponse, 403: errorResponse, 429: errorResponse },
      },
    },
    '/api/auth/logout': { post: { tags: ['Auth'], summary: 'Log out', security: csrf, responses: { 204: { description: 'Logged out' }, 403: errorResponse } } },
    '/api/auth/me': { get: { tags: ['Auth'], summary: 'Current user', security: [{ cookieAuth: [] }], responses: { 200: { description: 'User' }, 401: errorResponse } } },
    '/api/moods': {
      get: { tags: ['Mood journal'], summary: 'Last 30 check-ins (oldest first)', security: [{ cookieAuth: [] }], responses: { 200: { description: 'Entries' }, 401: errorResponse } },
      post: {
        tags: ['Mood journal'], summary: 'Save today\'s check-in (updates if one exists for that date)', security: [{ cookieAuth: [] }, ...csrf],
        requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/MoodInput' } } } },
        responses: { 200: { description: 'Saved' }, 400: errorResponse, 401: errorResponse, 403: errorResponse },
      },
      delete: { tags: ['Mood journal'], summary: 'Delete all of my check-ins', security: [{ cookieAuth: [] }, ...csrf], responses: { 204: { description: 'Cleared' }, 401: errorResponse, 403: errorResponse } },
    },
    '/api/moods/insights': {
      get: {
        tags: ['Mood journal'], summary: 'Average stress, trend, streak and a personalised recommendation', security: [{ cookieAuth: [] }],
        parameters: [{ name: 'today', in: 'query', required: false, schema: { type: 'string', example: '2026-11-26' } }],
        responses: { 200: { description: 'Insights' }, 400: errorResponse, 401: errorResponse },
      },
    },
  },
  components: {
    securitySchemes: {
      cookieAuth: { type: 'apiKey', in: 'cookie', name: 'token' },
      csrfToken: { type: 'apiKey', in: 'header', name: 'X-CSRF-Token' },
    },
    schemas: {
      Error: {
        type: 'object',
        properties: { error: { type: 'object', properties: { code: { type: 'string' }, message: { type: 'string' }, details: { type: 'array', items: { type: 'object' } } } } },
      },
      Credentials: {
        type: 'object', required: ['email', 'password'],
        properties: { email: { type: 'string', format: 'email' }, password: { type: 'string', minLength: 8, maxLength: 72 } },
      },
      MoodInput: {
        type: 'object', required: ['mood', 'stress'],
        properties: {
          entryDate: { type: 'string', example: '2026-11-26' },
          mood: { type: 'string', enum: ['happy', 'calm', 'neutral', 'anxious', 'tired'] },
          stress: { type: 'integer', minimum: 1, maximum: 5 },
          note: { type: 'string', maxLength: 500 },
        },
      },
    },
  },
};
