import type { RequestHandler } from 'express';
import rateLimit from 'express-rate-limit';

const passthrough: RequestHandler = (_req, _res, next) => next();

function limiter(windowMs: number, limit: number, message: string): RequestHandler {
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: { code: 'RATE_LIMITED', message } },
  });
}

export function createRateLimiters(enabled: boolean): { api: RequestHandler; auth: RequestHandler } {
  if (!enabled) return { api: passthrough, auth: passthrough };
  return {
    api: limiter(15 * 60 * 1000, 300, 'Too many requests. Please slow down and try again shortly.'),
    // Much stricter on login/register to slow down password guessing.
    auth: limiter(15 * 60 * 1000, 10, 'Too many login attempts. Please wait 15 minutes and try again.'),
  };
}
