import type { RequestHandler } from 'express';
import type { ZodTypeAny } from 'zod';
import { ValidationError } from '../errors/AppError';

/** Validates req.body (or req.query) with a Zod schema and replaces it with the parsed, typed value. */
export function validate(schema: ZodTypeAny, source: 'body' | 'query' = 'body'): RequestHandler {
  return (req, _res, next) => {
    const result = schema.safeParse(req[source]);
    if (!result.success) {
      const details = result.error.issues.map((i) => ({ field: i.path.join('.'), message: i.message }));
      return next(new ValidationError('Please check your input.', details));
    }
    (req as unknown as Record<string, unknown>)[source] = result.data;
    next();
  };
}
