import crypto from 'crypto';
import type { RequestHandler } from 'express';
import { ForbiddenError } from '../errors/AppError';

export const CSRF_COOKIE = 'csrf_token';
export const CSRF_HEADER = 'x-csrf-token';
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

function safeEqual(a: string, b: string): boolean {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

/**
 * Double-submit-cookie CSRF protection. Every state-changing request must send the
 * csrf_token cookie AND the same value in the X-CSRF-Token header. A cross-site page can
 * make the browser send the cookie but cannot read it, so it cannot add the header.
 */
export function csrfProtection(): RequestHandler {
  return (req, _res, next) => {
    if (SAFE_METHODS.has(req.method)) return next();
    const cookie = req.cookies?.[CSRF_COOKIE];
    const header = req.get(CSRF_HEADER);
    if (typeof cookie !== 'string' || typeof header !== 'string' || !safeEqual(cookie, header)) {
      return next(new ForbiddenError('Invalid or missing CSRF token. Refresh the page and try again.'));
    }
    next();
  };
}

/** GET /api/csrf-token: hands the browser a token (reusing its existing one so tabs stay in sync). */
export function issueCsrfToken(opts: { secure: boolean }): RequestHandler {
  return (req, res) => {
    const existing = req.cookies?.[CSRF_COOKIE];
    const token =
      typeof existing === 'string' && /^[a-f0-9]{64}$/.test(existing)
        ? existing
        : crypto.randomBytes(32).toString('hex');
    res.cookie(CSRF_COOKIE, token, {
      httpOnly: false, // the front end must read it to echo it in the header
      sameSite: 'strict',
      secure: opts.secure,
      path: '/',
    });
    res.json({ csrfToken: token });
  };
}
