import type { RequestHandler } from 'express';
import { AuthError } from '../errors/AppError';
import type { AuthService } from '../services/auth.service';

export const TOKEN_COOKIE = 'token';

/** Requires a valid JWT in the httpOnly cookie and exposes the user id as req.userId. */
export function createRequireAuth(auth: AuthService): RequestHandler {
  return (req, _res, next) => {
    const token = req.cookies?.[TOKEN_COOKIE];
    if (typeof token !== 'string' || token.length === 0) {
      return next(new AuthError('Please log in to continue.'));
    }
    try {
      req.userId = auth.verifyToken(token);
      next();
    } catch (err) {
      next(err);
    }
  };
}
