import type { ErrorRequestHandler, RequestHandler } from 'express';
import type { Logger } from 'pino';
import { AppError, NotFoundError } from '../errors/AppError';

export const notFoundHandler: RequestHandler = (_req, _res, next) => {
  next(new NotFoundError('That page or endpoint does not exist.'));
};

interface BodyParserError {
  type: string;
}
const isBodyParserError = (e: unknown): e is BodyParserError =>
  typeof e === 'object' && e !== null && typeof (e as BodyParserError).type === 'string';

/** Single place where every error becomes a consistent JSON response. Internals are never leaked. */
export function createErrorHandler(logger: Logger): ErrorRequestHandler {
  return (err, req, res, _next) => {
    if (err instanceof AppError) {
      res.status(err.statusCode).json({
        error: { code: err.code, message: err.message, ...(err.details ? { details: err.details } : {}) },
      });
      return;
    }
    if (isBodyParserError(err) && err.type === 'entity.parse.failed') {
      res.status(400).json({ error: { code: 'INVALID_JSON', message: 'Request body is not valid JSON.' } });
      return;
    }
    if (isBodyParserError(err) && err.type === 'entity.too.large') {
      res.status(413).json({ error: { code: 'PAYLOAD_TOO_LARGE', message: 'Request body is too large.' } });
      return;
    }
    logger.error({ err, method: req.method, url: req.originalUrl }, 'Unhandled error');
    res
      .status(500)
      .json({ error: { code: 'INTERNAL_ERROR', message: 'Something went wrong on our side. Please try again.' } });
  };
}
