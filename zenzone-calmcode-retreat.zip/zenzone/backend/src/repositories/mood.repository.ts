import type { DB } from '../db/database';
import type { Mood, MoodEntry } from '../types/domain';

interface MoodRow {
  id: number;
  entry_date: string;
  mood: Mood;
  stress: number;
  note: string;
  created_at: string;
}

export interface NewMoodEntry {
  entryDate: string;
  mood: Mood;
  stress: number;
  note: string;
}

const toEntry = (r: MoodRow): MoodEntry => ({
  id: r.id,
  entryDate: r.entry_date,
  mood: r.mood,
  stress: r.stress,
  note: r.note,
  createdAt: r.created_at,
});

export class MoodRepository {
  constructor(private readonly db: DB) {}

  /** One entry per user per day: saving again on the same day updates it. */
  upsert(userId: number, entry: NewMoodEntry): MoodEntry {
    this.db
      .prepare(
        `INSERT INTO mood_entries (user_id, entry_date, mood, stress, note)
         VALUES (@userId, @entryDate, @mood, @stress, @note)
         ON CONFLICT (user_id, entry_date)
         DO UPDATE SET mood = excluded.mood, stress = excluded.stress, note = excluded.note`,
      )
      .run({ userId, ...entry });

    const row = this.db
      .prepare('SELECT * FROM mood_entries WHERE user_id = ? AND entry_date = ?')
      .get(userId, entry.entryDate) as MoodRow;
    return toEntry(row);
  }

  /** Most recent `limit` entries, returned oldest-first so charts read left to right. */
  recent(userId: number, limit: number): MoodEntry[] {
    const rows = this.db
      .prepare('SELECT * FROM mood_entries WHERE user_id = ? ORDER BY entry_date DESC LIMIT ?')
      .all(userId, limit) as MoodRow[];
    return rows.reverse().map(toEntry);
  }

  deleteAll(userId: number): number {
    return this.db.prepare('DELETE FROM mood_entries WHERE user_id = ?').run(userId).changes;
  }
}
