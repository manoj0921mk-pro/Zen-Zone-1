import cookieParser from 'cookie-parser';
import express, { Express } from 'express';
import helmet from 'helmet';
import swaggerUi from 'swagger-ui-express';
import type { AppConfig } from './config/env';
import { createAuthController } from './controllers/auth.controller';
import { createMoodController } from './controllers/mood.controller';
import type { DB } from './db/database';
import { openApiSpec } from './docs/openapi';
import { createRequireAuth } from './middleware/auth';
import { csrfProtection } from './middleware/csrf';
import { createErrorHandler, notFoundHandler } from './middleware/errorHandler';
import { createRateLimiters } from './middleware/rateLimit';
import { MoodRepository } from './repositories/mood.repository';
import { UserRepository } from './repositories/user.repository';
import { createApiRouter } from './routes';
import { AuthService } from './services/auth.service';
import { MoodService } from './services/mood.service';
import { createLogger } from './utils/logger';

export interface AppDeps {
  db: DB;
  config: AppConfig;
}

/**
 * Composition root: wires repositories -> services -> controllers -> routes.
 * Nothing here contains business logic; it only connects the layers.
 */
export function createApp({ db, config }: AppDeps): Express {
  const logger = createLogger({ level: config.logLevel, enabled: config.logEnabled });

  // Layers
  const users = new UserRepository(db);
  const moodRepo = new MoodRepository(db);
  const authService = new AuthService(users, {
    secret: config.jwtSecret,
    expiresSeconds: config.jwtExpiresSeconds,
    bcryptRounds: config.bcryptRounds,
  });
  const moodService = new MoodService(moodRepo);
  const limiters = createRateLimiters(config.rateLimitEnabled);

  const app = express();
  app.disable('x-powered-by');

  // API docs need inline scripts/styles, so they get their own relaxed helmet config (mounted before the strict one).
  app.use('/docs', helmet({ contentSecurityPolicy: false }), swaggerUi.serve, swaggerUi.setup(openApiSpec));
  app.get('/openapi.json', (_req, res) => {
    res.json(openApiSpec);
  });

  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: true,
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'"],
          imgSrc: ["'self'", 'data:'],
          connectSrc: ["'self'"],
          manifestSrc: ["'self'"],
          workerSrc: ["'self'"],
          objectSrc: ["'none'"],
          frameAncestors: ["'none'"],
          upgradeInsecureRequests: config.secureCookies ? [] : null,
        },
      },
    }),
  );

  app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
      logger.info({ method: req.method, url: req.originalUrl, status: res.statusCode, ms: Date.now() - start }, 'request');
    });
    next();
  });

  app.use(express.json({ limit: '10kb' }));
  app.use(cookieParser());

  app.use(
    '/api',
    limiters.api,
    csrfProtection(),
    createApiRouter({
      authController: createAuthController(authService, {
        secure: config.secureCookies,
        maxAgeMs: config.jwtExpiresSeconds * 1000,
      }),
      moodController: createMoodController(moodService),
      requireAuth: createRequireAuth(authService),
      authLimiter: limiters.auth,
      secureCookies: config.secureCookies,
    }),
  );

  app.use(express.static(config.frontendDir));
  app.use(notFoundHandler);
  app.use(createErrorHandler(logger));

  return app;
}
