import { loadEnv, toAppConfig } from './config/env';
import { createApp } from './app';
import { createDatabase } from './db/database';
import { createLogger } from './utils/logger';

const env = loadEnv();
const config = toAppConfig(env);
const logger = createLogger({ level: config.logLevel, enabled: config.logEnabled });

const db = createDatabase(env.DB_PATH);
const app = createApp({ db, config });

const server = app.listen(env.PORT, () => {
  logger.info(`ZenZone running at http://localhost:${env.PORT} (API docs at /docs)`);
});

function shutdown(signal: string): void {
  logger.info(`${signal} received, shutting down`);
  server.close(() => {
    db.close();
    process.exit(0);
  });
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
