import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { ApiError, api, resetCsrfToken } from '../js/api.js';

const json = (status: number, body: unknown) => ({
  ok: status >= 200 && status < 300,
  status,
  json: async () => body,
});

let fetchMock: ReturnType<typeof vi.fn>;
beforeEach(() => {
  resetCsrfToken();
  fetchMock = vi.fn();
  vi.stubGlobal('fetch', fetchMock);
});
afterEach(() => vi.unstubAllGlobals());

describe('api client', () => {
  it('GET requests send cookies but no CSRF header', async () => {
    fetchMock.mockResolvedValueOnce(json(200, { entries: [] }));
    await api.listMoods();
    const [, init] = fetchMock.mock.calls[0];
    expect(init.credentials).toBe('same-origin');
    expect(init.headers['X-CSRF-Token']).toBeUndefined();
  });

  it('POST fetches a CSRF token first and sends it in the header', async () => {
    fetchMock
      .mockResolvedValueOnce(json(200, { csrfToken: 'tok123' }))
      .mockResolvedValueOnce(json(200, { entry: {} }));
    await api.saveMood({ mood: 'calm', stress: 2 });

    expect(fetchMock.mock.calls[0][0]).toBe('/api/csrf-token');
    const [url, init] = fetchMock.mock.calls[1];
    expect(url).toBe('/api/moods');
    expect(init.headers['X-CSRF-Token']).toBe('tok123');
    expect(JSON.parse(init.body)).toEqual({ mood: 'calm', stress: 2 });
  });

  it('reuses the CSRF token for later writes', async () => {
    fetchMock
      .mockResolvedValueOnce(json(200, { csrfToken: 'tok' }))
      .mockResolvedValueOnce(json(200, {}))
      .mockResolvedValueOnce(json(200, {}));
    await api.login('a@b.co', 'Calm1234');
    await api.login('a@b.co', 'Calm1234');
    expect(fetchMock.mock.calls.filter((c) => c[0] === '/api/csrf-token')).toHaveLength(1);
  });

  it('turns validation details into one readable message', async () => {
    fetchMock
      .mockResolvedValueOnce(json(200, { csrfToken: 't' }))
      .mockResolvedValueOnce(json(400, { error: { code: 'VALIDATION_ERROR', message: 'Please check your input.', details: [{ message: 'Password must contain a number' }, { message: 'Enter a valid email address' }] } }));
    await expect(api.register('x', 'y')).rejects.toMatchObject({
      name: 'ApiError', status: 400, message: 'Password must contain a number Enter a valid email address',
    });
  });

  it('maps a network failure to a friendly NETWORK_ERROR', async () => {
    fetchMock.mockRejectedValue(new TypeError('Failed to fetch'));
    const err = await api.listMoods().catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect(err.code).toBe('NETWORK_ERROR');
    expect(err.message).toMatch(/connection/i);
  });

  it('retries once with a fresh CSRF token after a 403 FORBIDDEN', async () => {
    fetchMock
      .mockResolvedValueOnce(json(200, { csrfToken: 'old' }))
      .mockResolvedValueOnce(json(403, { error: { code: 'FORBIDDEN', message: 'bad csrf' } }))
      .mockResolvedValueOnce(json(200, { csrfToken: 'new' }))
      .mockResolvedValueOnce(json(200, { ok: true }));
    await expect(api.clearMoods()).resolves.toEqual({ ok: true });
    expect(fetchMock.mock.calls[3][1].headers['X-CSRF-Token']).toBe('new');
  });

  it('returns null for 204 responses and exposes 401 status', async () => {
    fetchMock.mockResolvedValueOnce(json(401, { error: { code: 'AUTH_ERROR', message: 'Please log in to continue.' } }));
    const err = await api.me().catch((e) => e);
    expect(err.status).toBe(401);
    expect(err.code).toBe('AUTH_ERROR');
  });
});
