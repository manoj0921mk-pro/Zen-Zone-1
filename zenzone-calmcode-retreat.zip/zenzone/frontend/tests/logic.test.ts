import { describe, expect, it } from 'vitest';
import {
  BREATHING_PATTERNS, barHeight, formatTime, initialBreathState, moodEmoji,
  nextBreathState, sosStepFor, todayISO, validateCredentials,
} from '../js/logic.js';

describe('formatTime', () => {
  it('formats seconds as mm:ss', () => {
    expect(formatTime(125)).toBe('02:05');
    expect(formatTime(0)).toBe('00:00');
    expect(formatTime(600)).toBe('10:00');
  });
  it('never shows negative time', () => {
    expect(formatTime(-5)).toBe('00:00');
  });
});

describe('breathing state machine', () => {
  const box = BREATHING_PATTERNS.box.durations;
  const relax = BREATHING_PATTERNS.relax.durations; // [4,7,8,0]

  it('starts at inhale with the first duration', () => {
    expect(initialBreathState(box)).toEqual({ phase: 0, remaining: 4 });
  });

  it('counts down inside a phase', () => {
    expect(nextBreathState({ phase: 0, remaining: 4 }, box)).toEqual({ phase: 0, remaining: 3 });
  });

  it('moves to the next phase when the count reaches zero', () => {
    expect(nextBreathState({ phase: 0, remaining: 1 }, box)).toEqual({ phase: 1, remaining: 4 });
    expect(nextBreathState({ phase: 3, remaining: 1 }, box)).toEqual({ phase: 0, remaining: 4 });
  });

  it('skips phases whose duration is 0 (4-7-8 has no final hold)', () => {
    expect(nextBreathState({ phase: 2, remaining: 1 }, relax)).toEqual({ phase: 0, remaining: 4 });
  });

  it('completes a full box cycle in 16 ticks', () => {
    let s = initialBreathState(box);
    for (let i = 0; i < 16; i++) s = nextBreathState(s, box);
    expect(s).toEqual({ phase: 0, remaining: 4 });
  });
});

describe('sosStepFor', () => {
  it('advances a step every 30 seconds and caps at the last step', () => {
    expect(sosStepFor(120)).toBe(0);
    expect(sosStepFor(91)).toBe(0);
    expect(sosStepFor(90)).toBe(1);
    expect(sosStepFor(60)).toBe(2);
    expect(sosStepFor(30)).toBe(3);
    expect(sosStepFor(0)).toBe(3);
  });
});

describe('validateCredentials', () => {
  it('accepts a good email and password', () => {
    expect(validateCredentials('a@b.co', 'Calm1234')).toEqual([]);
  });
  it('reports every problem', () => {
    const errors = validateCredentials('nope', 'abc');
    expect(errors.length).toBeGreaterThanOrEqual(3);
  });
  it('requires a letter and a number', () => {
    expect(validateCredentials('a@b.co', '12345678')).toContain('Password must contain a letter.');
    expect(validateCredentials('a@b.co', 'abcdefgh')).toContain('Password must contain a number.');
  });
  it('rejects over-long passwords', () => {
    expect(validateCredentials('a@b.co', 'a1'.repeat(40))).toContain('Password must be 72 characters or fewer.');
  });
});

describe('small helpers', () => {
  it('todayISO uses the local calendar date', () => {
    expect(todayISO(new Date(2026, 10, 26))).toBe('2026-11-26');
    expect(todayISO(new Date(2026, 0, 5))).toBe('2026-01-05');
  });
  it('moodEmoji falls back safely', () => {
    expect(moodEmoji('anxious')).toBe('😟');
    expect(moodEmoji('???')).toBe('🙂');
  });
  it('barHeight clamps to the 1-5 scale', () => {
    expect(barHeight(3)).toBe(66);
    expect(barHeight(99)).toBe(110);
    expect(barHeight('x')).toBe(22);
  });
});
