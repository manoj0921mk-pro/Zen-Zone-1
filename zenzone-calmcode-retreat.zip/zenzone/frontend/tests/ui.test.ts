// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { renderChart, renderEntries, renderInsights, renderMoodPicker, renderPoses, setBusy, showToast } from '../js/ui.js';

const entry = (over = {}) => ({ id: 1, entryDate: '2026-11-26', mood: 'calm', stress: 3, note: '', ...over });
const insights = (over = {}) => ({
  entryCount: 3, averageStress: 2.7, streak: 3, trend: 'improving',
  recommendation: { title: 'Desk Yoga', reason: 'Stretch it out.', action: 'yoga' }, ...over,
});

let box: HTMLElement;
beforeEach(() => {
  document.body.innerHTML = '<div id="box"></div><div id="toast" hidden></div>';
  box = document.getElementById('box') as HTMLElement;
});

describe('renderEntries', () => {
  it('shows an empty state', () => {
    renderEntries(box, []);
    expect(box.textContent).toContain('No entries yet.');
  });

  it('shows the 7 most recent entries, newest first', () => {
    const entries = Array.from({ length: 9 }, (_, i) => entry({ entryDate: `2026-11-${10 + i}` }));
    renderEntries(box, entries);
    const rows = box.querySelectorAll('p');
    expect(rows).toHaveLength(7);
    expect(rows[0].textContent).toContain('2026-11-18');
  });

  it('never interprets notes as HTML (XSS safe)', () => {
    renderEntries(box, [entry({ note: '<img src=x onerror=alert(1)>' })]);
    expect(box.querySelector('img')).toBeNull();
    expect(box.textContent).toContain('<img src=x onerror=alert(1)>');
  });
});

describe('renderChart', () => {
  it('draws one bar per entry with a height from the stress level', () => {
    renderChart(box, [entry({ stress: 1 }), entry({ stress: 5 })]);
    const bars = box.querySelectorAll<HTMLElement>('.bar');
    expect(bars).toHaveLength(2);
    expect(bars[0].style.height).toBe('22px');
    expect(bars[1].style.height).toBe('110px');
  });
});

describe('renderInsights', () => {
  it('shows stats and a recommendation button that triggers the action', () => {
    const onAction = vi.fn();
    renderInsights(box, insights(), onAction);
    expect(box.textContent).toContain('3 🔥');
    expect(box.textContent).toContain('2.7');
    box.querySelector('button')!.click();
    expect(onAction).toHaveBeenCalledWith('yoga');
  });

  it('shows a friendly prompt when there is no data yet', () => {
    renderInsights(box, insights({ entryCount: 0 }), () => {});
    expect(box.textContent).toContain('Save your first check-in');
  });
});

describe('renderMoodPicker', () => {
  it('marks the selected mood and reports clicks', () => {
    const onSelect = vi.fn();
    renderMoodPicker(box, 'calm', onSelect);
    const buttons = box.querySelectorAll('button');
    expect(buttons).toHaveLength(5);
    expect(box.querySelectorAll('[aria-pressed="true"]')).toHaveLength(1);
    buttons[3].click();
    expect(onSelect).toHaveBeenCalledWith('anxious');
    expect(box.querySelector('[aria-pressed="true"]')!.getAttribute('aria-label')).toBe('Anxious');
  });
});

describe('misc UI', () => {
  it('renders all 10 desk yoga poses', () => {
    renderPoses(box);
    expect(box.querySelectorAll('.pose')).toHaveLength(10);
  });

  it('showToast displays then auto-hides the message', () => {
    vi.useFakeTimers();
    showToast('error', 'Oops', 1000);
    const toast = document.getElementById('toast')!;
    expect(toast.hidden).toBe(false);
    expect(toast.className).toContain('error');
    vi.advanceTimersByTime(1001);
    expect(toast.hidden).toBe(true);
    vi.useRealTimers();
  });

  it('setBusy disables the button and sets aria-busy', () => {
    const b = document.createElement('button');
    setBusy(b, true);
    expect(b.disabled).toBe(true);
    expect(b.getAttribute('aria-busy')).toBe('true');
    setBusy(b, false);
    expect(b.disabled).toBe(false);
  });
});
