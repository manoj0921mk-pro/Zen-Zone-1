// Interactive calm tools. Each factory takes the DOM nodes it controls and returns start/stop functions.
import {
  BREATHING_PATTERNS, PHASE_NAMES, PHASE_SCALE, SOS_CUES, SOS_SECONDS, SOS_TEXTS,
  formatTime, initialBreathState, nextBreathState, sosStepFor,
} from './logic.js';

export function createBreathing({ select, circle, cue, count }) {
  let timer = null;
  let state = null;
  const durations = () => (BREATHING_PATTERNS[select.value] || BREATHING_PATTERNS.box).durations;

  function render() {
    cue.textContent = PHASE_NAMES[state.phase];
    count.textContent = String(state.remaining);
    circle.style.transitionDuration = `${durations()[state.phase]}s`;
    circle.style.transform = `scale(${PHASE_SCALE[state.phase]})`;
  }

  function reset() {
    clearInterval(timer);
    timer = null;
    cue.textContent = 'Ready?';
    count.textContent = String(durations()[0]);
    circle.style.transitionDuration = '1s';
    circle.style.transform = 'scale(1)';
  }

  function start() {
    if (timer) return;
    state = initialBreathState(durations());
    render();
    timer = setInterval(() => {
      state = nextBreathState(state, durations());
      render();
    }, 1000);
  }

  select.addEventListener('change', reset);
  return { start, reset };
}

export function createMeditation({ select, clock, message }) {
  let timer = null;
  let left = 0;
  const total = () => Number(select.value) * 60;

  function reset() {
    clearInterval(timer);
    timer = null;
    left = total();
    clock.textContent = formatTime(left);
    message.textContent = 'Sit comfortably and relax.';
  }

  function start() {
    clearInterval(timer);
    left = total();
    clock.textContent = formatTime(left);
    message.textContent = 'Breathe slowly. Let thoughts pass by.';
    timer = setInterval(() => {
      left--;
      clock.textContent = formatTime(left);
      if (left <= 0) {
        clearInterval(timer);
        timer = null;
        message.textContent = 'Session complete. Take this calm with you!';
      }
    }, 1000);
  }

  select.addEventListener('change', reset);
  return { start, reset };
}

export function createSOS({ circle, cue, prompt, step, clock }) {
  let timer = null;
  let left = SOS_SECONDS;

  function render() {
    const i = sosStepFor(left);
    const done = left <= 0;
    clock.textContent = formatTime(left);
    prompt.textContent = done ? 'You made space for a pause. Take your next step gently.' : SOS_TEXTS[i];
    step.textContent = done ? 'Complete' : `Step ${i + 1} of 4`;
    cue.textContent = SOS_CUES[i];
    circle.style.transform = i === 1 ? 'scale(1.15)' : i === 2 ? 'scale(.85)' : 'scale(1)';
  }

  function end() {
    clearInterval(timer);
    timer = null;
  }

  function start() {
    end();
    left = SOS_SECONDS;
    render();
    timer = setInterval(() => {
      left--;
      render();
      if (left <= 0) end();
    }, 1000);
  }

  return { start, end };
}

export function createSoundscape({ select, button, volume }) {
  let ctx = null;
  let nodes = null;
  let bellTimer = null;
  const level = () => (Number(volume.value) / 100) * 0.3;

  function noiseBuffer(audio) {
    const buffer = audio.createBuffer(1, audio.sampleRate * 2, audio.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    return buffer;
  }

  function start() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return false;
    ctx = ctx || new AudioCtx();
    if (ctx.resume) ctx.resume();

    const master = ctx.createGain();
    master.gain.value = level();
    master.connect(ctx.destination);

    if (select.value === 'bell') {
      const ring = () => {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = 528;
        g.gain.setValueAtTime(0.0001, ctx.currentTime);
        g.gain.exponentialRampToValueAtTime(1, ctx.currentTime + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 4);
        osc.connect(g);
        g.connect(master);
        osc.start();
        osc.stop(ctx.currentTime + 4.1);
      };
      ring();
      bellTimer = setInterval(ring, 6000);
      nodes = { master };
    } else {
      const src = ctx.createBufferSource();
      src.buffer = noiseBuffer(ctx);
      src.loop = true;
      const filter = ctx.createBiquadFilter();
      if (select.value === 'rain') { filter.type = 'lowpass'; filter.frequency.value = 1400; }
      else if (select.value === 'forest') { filter.type = 'bandpass'; filter.frequency.value = 500; filter.Q.value = 0.5; }
      else { filter.type = 'lowpass'; filter.frequency.value = 20000; }
      src.connect(filter);
      filter.connect(master);
      src.start();
      nodes = { src, master };
    }
    button.textContent = 'Ⅱ Stop';
    return true;
  }

  function stop() {
    clearInterval(bellTimer);
    bellTimer = null;
    if (nodes) {
      try { if (nodes.src) nodes.src.stop(); } catch { /* already stopped */ }
      nodes.master.disconnect();
      nodes = null;
    }
    button.textContent = '▶ Play';
  }

  volume.addEventListener('input', () => { if (nodes) nodes.master.gain.value = level(); });
  select.addEventListener('change', () => { if (nodes) { stop(); start(); } });

  return { toggle: () => (nodes ? stop() : start()), stop, isPlaying: () => nodes !== null };
}
