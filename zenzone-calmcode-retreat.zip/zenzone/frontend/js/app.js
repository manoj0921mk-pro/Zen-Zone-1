// Entry point: wires the HTML to the API and the calm tools.
import { ApiError, api } from './api.js';
import { createBreathing, createMeditation, createSOS, createSoundscape } from './features.js';
import { AFFIRMATIONS, BREATHING_PATTERNS, todayISO, validateCredentials } from './logic.js';
import { renderChart, renderEntries, renderInsights, renderMoodPicker, renderPoses, setBusy, showToast } from './ui.js';

const $ = (id) => document.getElementById(id);

let selectedMood = 'calm';

// ---------- calm tools ----------
for (const [key, p] of Object.entries(BREATHING_PATTERNS)) {
  const opt = document.createElement('option');
  opt.value = key;
  opt.textContent = p.name;
  $('breathPattern').append(opt);
}

const breathing = createBreathing({ select: $('breathPattern'), circle: $('breathCircle'), cue: $('breathCue'), count: $('breathCount') });
const meditation = createMeditation({ select: $('medDuration'), clock: $('medClock'), message: $('medMessage') });
const sos = createSOS({ circle: $('sosCircle'), cue: $('sosCue'), prompt: $('sosPrompt'), step: $('sosStep'), clock: $('sosClock') });
const sound = createSoundscape({ select: $('soundType'), button: $('soundBtn'), volume: $('volume') });

renderPoses($('poses'));

function openDialog(id) {
  const dialog = $(id);
  if (!dialog.open) dialog.showModal();
}

document.querySelectorAll('[data-open]').forEach((b) => b.addEventListener('click', () => openDialog(b.dataset.open)));
document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => b.closest('dialog').close()));

// Stop timers/sound whenever a dialog closes (button, Esc key or backdrop).
$('breathDialog').addEventListener('close', breathing.reset);
$('medDialog').addEventListener('close', meditation.reset);
$('soundDialog').addEventListener('close', sound.stop);
$('sosDialog').addEventListener('close', sos.end);

$('breathStart').addEventListener('click', breathing.start);
$('breathReset').addEventListener('click', breathing.reset);
$('medStart').addEventListener('click', meditation.start);
$('medReset').addEventListener('click', meditation.reset);
$('soundBtn').addEventListener('click', () => {
  if (sound.toggle() === false) showToast('error', 'Your browser does not support audio playback.');
});
$('startSos').addEventListener('click', () => {
  openDialog('sosDialog');
  sos.start();
});

function runRecommendation(action) {
  if (action === 'sos') {
    openDialog('sosDialog');
    sos.start();
  } else if (action.startsWith('breathing:')) {
    $('breathPattern').value = action.split(':')[1];
    breathing.reset();
    openDialog('breathDialog');
  } else if (action === 'yoga') {
    openDialog('yogaDialog');
  } else {
    openDialog('medDialog');
  }
}

$('newAffirmation').addEventListener('click', () => {
  $('affirmation').textContent = AFFIRMATIONS[Math.floor(Math.random() * AFFIRMATIONS.length)];
});

// ---------- session ----------
function setUser(user) {
  const loggedIn = Boolean(user);
  $('authCard').hidden = loggedIn;
  $('journalArea').hidden = !loggedIn;
  $('insightsCard').hidden = !loggedIn;
  $('userEmail').hidden = !loggedIn;
  $('logoutBtn').hidden = !loggedIn;
  $('userEmail').textContent = loggedIn ? user.email : '';
}

function showFormError(message) {
  $('authError').textContent = message;
  $('authError').hidden = !message;
}

function handleError(err, fallback) {
  if (err instanceof ApiError && err.status === 401) {
    setUser(null);
    showToast('error', 'Your session has expired. Please log in again.');
    return;
  }
  showToast('error', err instanceof ApiError ? err.message : fallback);
}

async function loadJournal() {
  const [{ entries }, { insights }] = await Promise.all([api.listMoods(), api.insights(todayISO())]);
  renderEntries($('entries'), entries);
  renderChart($('chart'), entries);
  renderInsights($('insights'), insights, runRecommendation);
}

$('authForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const mode = event.submitter && event.submitter.value === 'register' ? 'register' : 'login';
  const email = $('email').value.trim();
  const password = $('password').value;

  const problems = mode === 'register'
    ? validateCredentials(email, password)
    : (email && password ? [] : ['Enter your email and password.']);
  if (problems.length) {
    showFormError(problems.join(' '));
    return;
  }

  showFormError('');
  const button = event.submitter;
  setBusy(button, true);
  try {
    const { user } = mode === 'register' ? await api.register(email, password) : await api.login(email, password);
    $('password').value = '';
    setUser(user);
    await loadJournal();
    showToast('success', mode === 'register' ? 'Account created. Welcome to ZenZone!' : 'Welcome back!');
  } catch (err) {
    showFormError(err instanceof ApiError ? err.message : 'Something went wrong. Please try again.');
  } finally {
    setBusy(button, false);
  }
});

$('logoutBtn').addEventListener('click', async () => {
  try {
    await api.logout();
  } catch (err) {
    handleError(err, 'Could not log out. Please try again.');
    return;
  }
  setUser(null);
  showToast('success', 'You have been logged out.');
});

$('goJournal').addEventListener('click', () => {
  $('journalHeading').scrollIntoView({ behavior: 'smooth' });
  const target = $('authCard').hidden ? $('saveMood') : $('email');
  target.focus({ preventScroll: true });
});

// ---------- journal ----------
renderMoodPicker($('moodPicker'), selectedMood, (m) => { selectedMood = m; });

$('stress').addEventListener('input', () => { $('stressVal').textContent = `${$('stress').value} / 5`; });
$('reflection').addEventListener('input', () => { $('noteCount').textContent = String($('reflection').value.length); });

$('saveMood').addEventListener('click', async () => {
  const button = $('saveMood');
  setBusy(button, true);
  try {
    await api.saveMood({
      entryDate: todayISO(),
      mood: selectedMood,
      stress: Number($('stress').value),
      note: $('reflection').value,
    });
    $('reflection').value = '';
    $('noteCount').textContent = '0';
    await loadJournal();
    showToast('success', 'Check-in saved.');
  } catch (err) {
    handleError(err, 'Could not save your check-in. Please try again.');
  } finally {
    setBusy(button, false);
  }
});

$('clearLogs').addEventListener('click', async () => {
  if (!window.confirm('Clear your whole journal? This cannot be undone.')) return;
  try {
    await api.clearMoods();
    await loadJournal();
    showToast('success', 'Journal cleared.');
  } catch (err) {
    handleError(err, 'Could not clear your journal. Please try again.');
  }
});

// ---------- start-up ----------
async function init() {
  try {
    const { user } = await api.me();
    setUser(user);
    await loadJournal();
  } catch (err) {
    setUser(null);
    if (err instanceof ApiError && err.code === 'NETWORK_ERROR') {
      showToast('error', 'You appear to be offline. The calm tools still work; log in when you are back online.');
    }
  }
}

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(() => { /* offline mode is optional */ });
}

init();
