// DOM rendering helpers. User text is only ever set through textContent, so it can never run as HTML (XSS-safe).
import { MOODS, POSES, TREND_LABELS, barHeight, formatDateLabel, moodEmoji } from './logic.js';

function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}

export function renderMoodPicker(container, selected, onSelect) {
  container.replaceChildren();
  for (const m of MOODS) {
    const b = el('button', m.emoji, 'mood');
    b.type = 'button';
    b.setAttribute('aria-label', m.label);
    b.setAttribute('aria-pressed', String(m.value === selected));
    b.addEventListener('click', () => {
      onSelect(m.value);
      renderMoodPicker(container, m.value, onSelect);
    });
    container.append(b);
  }
}

export function renderEntries(container, entries) {
  container.replaceChildren();
  if (!entries.length) {
    container.append(el('p', 'No entries yet.'));
    return;
  }
  for (const e of entries.slice(-7).reverse()) {
    const note = e.note ? ` — ${e.note}` : '';
    container.append(el('p', `${moodEmoji(e.mood)} ${e.entryDate} · Stress ${e.stress}/5${note}`));
  }
}

export function renderChart(container, entries) {
  container.replaceChildren();
  for (const e of entries.slice(-7)) {
    const box = el('div', undefined, 'barbox');
    const bar = el('div', undefined, 'bar');
    bar.style.height = `${barHeight(e.stress)}px`;
    bar.title = `Stress ${e.stress}/5`;
    box.append(bar, el('span', formatDateLabel(e.entryDate)));
    container.append(box);
  }
}

export function renderInsights(container, insights, onAction) {
  container.replaceChildren();
  if (!insights.entryCount) {
    container.append(el('p', 'Save your first check-in to unlock your streak, trend and a personalised suggestion.', 'muted'));
  } else {
    const stats = el('div', undefined, 'stats');
    const add = (value, label) => {
      const s = el('div', undefined, 'stat');
      s.append(el('b', String(value)), el('span', label));
      stats.append(s);
    };
    add(`${insights.streak} 🔥`, insights.streak === 1 ? 'day streak' : 'day streak');
    add(insights.averageStress, 'average stress');
    add(insights.entryCount, 'check-ins');
    container.append(stats, el('p', `Trend: ${TREND_LABELS[insights.trend] || ''}`));
  }

  const rec = insights.recommendation;
  const box = el('div', undefined, 'recommendation');
  const btn = el('button', `Try: ${rec.title}`);
  btn.type = 'button';
  btn.addEventListener('click', () => onAction(rec.action));
  box.append(el('h4', 'Suggested for you'), el('p', rec.reason), btn);
  container.append(box);
}

export function renderPoses(container) {
  container.replaceChildren();
  for (const [name, icon] of POSES) {
    const pose = el('div', undefined, 'pose');
    pose.append(el('span', icon), el('p', name));
    pose.querySelector('p').style.fontWeight = 'bold';
    container.append(pose);
  }
}

let toastTimer = null;
export function showToast(type, message, ms = 4500) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.className = `toast ${type}`;
  toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toast.hidden = true; }, ms);
}

export function setBusy(button, busy) {
  if (!button) return;
  button.disabled = busy;
  button.setAttribute('aria-busy', String(busy));
}
