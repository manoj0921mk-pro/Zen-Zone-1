// Pure, DOM-free helpers. Everything here is unit-tested (frontend/tests/logic.test.ts).

export const MOODS = [
  { value: 'happy', emoji: '😊', label: 'Happy' },
  { value: 'calm', emoji: '🙂', label: 'Calm' },
  { value: 'neutral', emoji: '😐', label: 'Neutral' },
  { value: 'anxious', emoji: '😟', label: 'Anxious' },
  { value: 'tired', emoji: '😴', label: 'Tired' },
];

export function moodEmoji(value) {
  const found = MOODS.find((m) => m.value === value);
  return found ? found.emoji : '🙂';
}

// [inhale, hold, exhale, hold] in seconds. A 0 means that phase is skipped.
export const BREATHING_PATTERNS = {
  box: { name: 'Box breathing (4-4-4-4)', durations: [4, 4, 4, 4] },
  relax: { name: 'Relaxing breath (4-7-8)', durations: [4, 7, 8, 0] },
  calm: { name: 'Calm breath (4-2-6)', durations: [4, 2, 6, 0] },
};
export const PHASE_NAMES = ['Inhale', 'Hold', 'Exhale', 'Hold'];
// Circle size per phase: grows while inhaling/holding full, shrinks while exhaling/holding empty.
export const PHASE_SCALE = [1.18, 1.18, 0.82, 0.82];

export function initialBreathState(durations) {
  return { phase: 0, remaining: durations[0] };
}

/** Advances the breathing timer by one second, skipping any phase whose duration is 0. */
export function nextBreathState(state, durations) {
  const remaining = state.remaining - 1;
  if (remaining > 0) return { phase: state.phase, remaining };

  let next = (state.phase + 1) % 4;
  for (let guard = 0; guard < 4 && durations[next] <= 0; guard++) {
    next = (next + 1) % 4;
  }
  return { phase: next, remaining: durations[next] };
}

export function formatTime(totalSeconds) {
  const s = Math.max(0, Math.floor(totalSeconds));
  return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
}

export const SOS_SECONDS = 120;
export const SOS_TEXTS = [
  'Put both feet on the floor. Relax your shoulders.',
  'Breathe in gently for four seconds.',
  'Breathe out slowly. You do not need to rush.',
  'Think of one small next step.',
];
export const SOS_CUES = ['Settle', 'Inhale', 'Exhale', 'Next step'];

/** Which of the 4 SOS steps (0-3) applies, given the seconds still left. Each step lasts 30s. */
export function sosStepFor(secondsLeft, total = SOS_SECONDS) {
  const elapsed = total - secondsLeft;
  return Math.min(3, Math.max(0, Math.floor(elapsed / 30)));
}

/** Local calendar date as YYYY-MM-DD (not UTC, so "today" matches the user's wall clock). */
export function todayISO(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function formatDateLabel(iso) {
  return typeof iso === 'string' ? iso.slice(5) : '';
}

export function barHeight(stress) {
  return Math.max(1, Math.min(5, Number(stress) || 1)) * 22;
}

/** Mirrors the server's registration rules so users get instant feedback. Returns a list of problems. */
export function validateCredentials(email, password) {
  const errors = [];
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email).trim())) errors.push('Enter a valid email address.');
  if (password.length < 8) errors.push('Password must be at least 8 characters.');
  if (password.length > 72) errors.push('Password must be 72 characters or fewer.');
  if (!/[A-Za-z]/.test(password)) errors.push('Password must contain a letter.');
  if (!/\d/.test(password)) errors.push('Password must contain a number.');
  return errors;
}

export const TREND_LABELS = {
  improving: 'Improving 📉 (stress is falling)',
  steady: 'Steady ➡️',
  worsening: 'Rising 📈 (be kind to yourself)',
  'not-enough-data': 'Need a few more check-ins',
};

export const POSES = [
  ['Neck Side Stretch', '↔️'], ['Shoulder Rolls', '🔄'], ['Seated Spinal Twist', '🪑'],
  ['Wrist Circles', '🖐️'], ['Seated Cat-Cow', '🐈'], ['Chest Opener', '👐'],
  ['Seated Forward Fold', '🙇'], ['Ankle Circles', '🦶'], ['Overhead Reach', '🙆'], ['Eye Rest', '👀'],
];

export const AFFIRMATIONS = [
  'I can take one step at a time.',
  'My effort matters more than one difficult moment.',
  'I am allowed to pause and begin again.',
  'I can focus on the question in front of me.',
  'A difficult exam does not define my worth.',
  'I will do my best.',
];
