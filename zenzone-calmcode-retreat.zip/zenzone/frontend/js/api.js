// Thin fetch wrapper: handles the CSRF token, cookies and turns every failure into a readable ApiError.

export class ApiError extends Error {
  constructor(message, status = 0, code = 'UNKNOWN', details = undefined) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

let csrfToken = null;

export function resetCsrfToken() {
  csrfToken = null;
}

async function ensureCsrf() {
  if (csrfToken) return csrfToken;
  const res = await fetch('/api/csrf-token', { credentials: 'same-origin' });
  if (!res.ok) throw new ApiError('Could not start a secure session. Please refresh the page.', res.status, 'CSRF_ERROR');
  csrfToken = (await res.json()).csrfToken;
  return csrfToken;
}

function messageFrom(data, fallback) {
  const err = data && data.error;
  if (!err) return fallback;
  if (Array.isArray(err.details) && err.details.length) {
    return err.details.map((d) => d.message).join(' ');
  }
  return err.message || fallback;
}

async function request(method, url, body, canRetry = true) {
  const headers = { Accept: 'application/json' };
  const isWrite = method !== 'GET';
  try {
    if (isWrite) {
      headers['Content-Type'] = 'application/json';
      headers['X-CSRF-Token'] = await ensureCsrf();
    }
  } catch (err) {
    if (err instanceof ApiError) throw err;
    throw new ApiError('Cannot reach the server. Check your connection.', 0, 'NETWORK_ERROR');
  }

  let res;
  try {
    res = await fetch(url, {
      method,
      headers,
      credentials: 'same-origin',
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError('Cannot reach the server. Check your connection.', 0, 'NETWORK_ERROR');
  }

  const data = res.status === 204 ? null : await res.json().catch(() => null);

  // A stale CSRF token (e.g. cookie cleared): fetch a fresh one and retry once.
  if (res.status === 403 && isWrite && canRetry && data && data.error && data.error.code === 'FORBIDDEN') {
    resetCsrfToken();
    return request(method, url, body, false);
  }

  if (!res.ok) {
    throw new ApiError(messageFrom(data, 'Something went wrong. Please try again.'), res.status, data?.error?.code, data?.error?.details);
  }
  return data;
}

export const api = {
  register: (email, password) => request('POST', '/api/auth/register', { email, password }),
  login: (email, password) => request('POST', '/api/auth/login', { email, password }),
  logout: () => request('POST', '/api/auth/logout'),
  me: () => request('GET', '/api/auth/me'),
  listMoods: () => request('GET', '/api/moods'),
  saveMood: (entry) => request('POST', '/api/moods', entry),
  clearMoods: () => request('DELETE', '/api/moods'),
  insights: (today) => request('GET', `/api/moods/insights?today=${encodeURIComponent(today)}`),
};
