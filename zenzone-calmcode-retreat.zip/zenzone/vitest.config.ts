import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['backend/tests/**/*.test.ts', 'frontend/tests/**/*.test.ts'],
    environment: 'node', // frontend DOM tests opt in with: // @vitest-environment jsdom
    coverage: {
      provider: 'v8',
      reporter: ['text', 'html'],
      include: ['backend/src/**/*.ts', 'frontend/js/**/*.js'],
      exclude: ['backend/src/server.ts', 'backend/src/docs/**', 'frontend/js/app.js'],
    },
  },
});
